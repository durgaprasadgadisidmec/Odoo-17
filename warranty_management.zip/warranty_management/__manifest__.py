{
    "name": "Product Warranty",
    "author": "Durga",
    "version": "17.0",
    "license": "LGPL-3",
    "depends": ["base","sale_management","stock",],
    "data":
        [
            "security/ir.model.access.csv",
            "views/product_template_form_inherit.xml",
             "views/views_warranty_form.xml",
            "views/menu.xml"

        ]

}


