from . import product_template_inherit
from . import warranty_menu