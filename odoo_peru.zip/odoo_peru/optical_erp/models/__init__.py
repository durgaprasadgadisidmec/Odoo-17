from . import dr_prescription
from . import doctor
from . import  test_type
from . import  res_partner
from . import  inherit_saleorder
from . import  res_config_settings
from . import complete_pair
from . import lens
# POS models
from . import pos_order
from . import product_attribute
from . import product_pos

from . import product_template #Nuevo
